import 'package:demo/screen/Profile.dart';
import 'package:flutter/material.dart';

import 'dart:convert';

import 'package:flutter/material.dart';

import '../api.dart';
import 'homePage.dart';

class Edit extends StatefulWidget {
  const Edit({super.key, required this.username});

  final String username;

  @override
  State<Edit> createState() => _EditState();
}

class _EditState extends State<Edit> with TickerProviderStateMixin {
  final TextEditingController _headerCnt = TextEditingController();
  final TextEditingController _titleCnt = TextEditingController();
  final TextEditingController _descCnt = TextEditingController();
  late String errString = '';
  late bool circular = false;
  late bool validate = true;
  //final storage = new FlutterSecureStorage();

  late AnimationController _controler1;
  late Animation<Offset> animation2;

  var vis = true;
  final _globalKey = GlobalKey<FormState>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controler1 = AnimationController(
        duration: Duration(milliseconds: 1400), vsync: this);

    animation2 = Tween<Offset>(begin: Offset(0.0, 1.0), end: Offset(0.0, 0.0))
        .animate(CurvedAnimation(parent: _controler1, curve: Curves.easeInOut));

    _controler1.forward();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _controler1.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Form(
          key: _globalKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Center(
                  child: Text(
                'Edit Your Post',
                style: TextStyle(color: Colors.purple, fontSize: 36),
              )),
              SlideTransition(
                position: animation2,
                child: Container(
                    width: MediaQuery.of(context).size.width - 200,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextFormField(
                            validator: ((value) {
                              if (value!.isEmpty) return 'Header is empty';
                            }),
                            controller: _headerCnt,
                            onChanged: (v) => {_headerCnt.text = v},
                            decoration: const InputDecoration(
                              //errorText: 'Invalid username',
                              //helperText: "type your Header",
                              helperStyle:
                                  TextStyle(color: Colors.blue, fontSize: 10),
                              border:
                                  OutlineInputBorder(), // UnderlineInputBorder( ),
                              labelText: "Header",
                            ),
                          ),
                        )
                      ],
                    )),
              ),
              SlideTransition(
                position: animation2,
                child: Container(
                    width: MediaQuery.of(context).size.width - 200,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextFormField(
                            validator: ((value) {
                              if (value!.isEmpty) return 'Title is empty';
                            }),
                            controller: _titleCnt,
                            onChanged: (v) => {_titleCnt.text = v},
                            decoration: const InputDecoration(
                              //errorText: 'Invalid username',
                              helperText: "type your Title",
                              helperStyle:
                                  TextStyle(color: Colors.blue, fontSize: 10),
                              border:
                                  OutlineInputBorder(), //UnderlineInputBorder(),
                              labelText: "Title",
                            ),
                          ),
                        )
                      ],
                    )),
              ),
              SlideTransition(
                position: animation2,
                child: Container(
                    width: MediaQuery.of(context).size.width - 200,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextFormField(
                            validator: ((value) {
                              if (value!.isEmpty) return 'Description is empty';
                            }),
                            maxLines: 5,
                            //obscureText: vis,
                            controller: _descCnt,
                            onChanged: (v) => {_descCnt.text = v},
                            decoration: InputDecoration(
                              helperText:
                                  "type your Description more then 8 chracter",
                              helperStyle:
                                  TextStyle(color: Colors.blue, fontSize: 10),
                              suffixIcon: IconButton(
                                icon: Icon(vis
                                    ? Icons.visibility_off
                                    : Icons.visibility),
                                onPressed: () => {
                                  setState(
                                    () {
                                      vis = !vis;
                                    },
                                  )
                                },
                              ),
                              border: OutlineInputBorder(),
                              labelText: "Description",
                            ),
                          ),
                        )
                      ],
                    )),
              ),
              SizedBox(
                height: 20,
              ),
              SlideTransition(
                position: animation2,
                child: ElevatedButton(
                    onPressed: () async {
                      setState(() => {circular = true});

                      // await checkUser();

                      Map<String, String> data = {
                        "header": _headerCnt.text,
                        "title": _titleCnt.text,
                        "desc": _descCnt.text
                      };
                      print(data);

                      var response =
                          await post2("/update/$widget.username", data);
                      print(response);

                      if (response.statusCode == 200 ||
                          response.statusCode == 201) {
                        Map<String, dynamic> output =
                            json.decode(response.body);
                        print(output);

                        setState(() {
                          validate = false;
                          circular = false;
                        });

                        Navigator.pushAndRemoveUntil(
                            context,
                            (MaterialPageRoute(
                                builder: (context) => Profile())),
                            (route) => false);
                      } else {
                        String outputi = json.decode(response.body);
                        setState(() {
                          circular = false;
                          errString = outputi; //'yes new user michel';
                        });
                      }

                      Navigator.pushAndRemoveUntil(
                          context,
                          (MaterialPageRoute(builder: (context) => Profile())),
                          (route) => false);
                    },
                    child: Container(
                      height: 50,
                      width: 300,
                      color: Colors.green,
                      padding: EdgeInsets.all(1),
                      child: circular
                          ? CircularProgressIndicator()
                          : const Text(
                              'Edit post',
                              style:
                                  TextStyle(color: Colors.white, fontSize: 20),
                            ),
                    )),
              )
            ],
          ),
        ),
      ),
    );
  }
}
