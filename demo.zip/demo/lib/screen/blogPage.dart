import 'package:demo/api.dart';
import 'package:flutter/material.dart';
import 'package:demo/screen/detail.dart';

class BlogPage extends StatefulWidget {
  const BlogPage({super.key});

  @override
  State<BlogPage> createState() => _BlogPageState();
}

class _BlogPageState extends State<BlogPage> {
  late Future<List<Blog>> blogs;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    blogs = fetchBlog();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: FutureBuilder<List<Blog>>(
            future: blogs,
            builder: (context, snapshot) {
              //print(blogs);
              if (snapshot.hasData) {
                return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: ((context, index) {
                    return Card(
                      elevation: 1,
                      margin: EdgeInsets.all(8),
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(8),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              height: 200,
                              // width: 200,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  image: DecorationImage(
                                      fit: BoxFit.cover,
                                      image: NetworkImage(
                                          "https://media.sproutsocial.com/uploads/2022/06/profile-picture.jpeg"))),
                            ),
                            ListTile(
                                title: Text(
                                  snapshot.data![index].header,
                                  style: TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold),
                                ),
                                subtitle: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      snapshot.data![index].title,
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w700),
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        InkWell(
                                          onTap: () {
                                            Navigator.of(context).push(
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        Detail(
                                                          blog: snapshot
                                                              .data![index],
                                                        )));
                                          },
                                          child: Container(
                                            //color: Colors.blue,
                                            padding: EdgeInsets.all(4),
                                            child: Center(
                                              child: Text(
                                                "read more..",
                                                style: TextStyle(
                                                    color: Colors.blue),
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ],
                                )),
                          ],
                        ),
                      ),
                    );
                  }),
                );
              }
              return Center(child: CircularProgressIndicator());
            }));
  }
}
