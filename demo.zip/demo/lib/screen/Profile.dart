import 'dart:convert';

import 'package:demo/screen/Edit.dart';
import 'package:flutter/material.dart';

import '../api.dart';

class Profile extends StatefulWidget {
  const Profile({
    super.key,
  });

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  late Future<List<Blog>> blogs;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    blogs = fetchBlog();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: FutureBuilder<List<Blog>>(
            future: blogs,
            builder: (context, snapshot) {
              //print(blogs);
              if (snapshot.hasData) {
                return ListView.builder(
                  itemCount: snapshot.data!.length,
                  itemBuilder: ((context, index) {
                    return Card(
                      elevation: 1,
                      margin: EdgeInsets.all(20),
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.all(8),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ListTile(
                                leading: Container(
                                  height: 100,
                                  width: 100,
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          fit: BoxFit.cover,
                                          image: NetworkImage(
                                              "https://media.sproutsocial.com/uploads/2022/06/profile-picture.jpeg"))),
                                ),
                                title: Text(
                                  snapshot.data![index].header,
                                  style: TextStyle(
                                      fontSize: 24,
                                      fontWeight: FontWeight.bold),
                                ),
                                subtitle: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      snapshot.data![index].title,
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w700),
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        InkWell(
                                          onTap: () async {
                                            var a =
                                                snapshot.data![index].header;
                                            var response =
                                                await get2("/delete/${a}}");
                                            print(response);

                                            if (response.statusCode == 200 ||
                                                response.statusCode == 201) {
                                              Map<String, dynamic> output =
                                                  json.decode(response.body);
                                              print(output);
                                            }
                                          },
                                          child: Container(
                                            //color: Colors.blue,
                                            padding: EdgeInsets.all(4),
                                            child: Center(
                                              child: Text(
                                                "delete",
                                                style: TextStyle(
                                                    color: Colors.blue),
                                              ),
                                            ),
                                          ),
                                        ),
                                        InkWell(
                                          onTap: () {
                                            String u =
                                                snapshot.data![index].header;
                                            Navigator.of(context).push(
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        Edit(username: u)));
                                          },
                                          child: Container(
                                            //color: Colors.blue,
                                            padding: EdgeInsets.all(4),
                                            child: Center(
                                              child: Text(
                                                "edit",
                                                style: TextStyle(
                                                    color: Colors.blue),
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ],
                                )),
                          ],
                        ),
                      ),
                    );
                  }),
                );
              }
              return Center(child: CircularProgressIndicator());
            }));
  }
}

Widget Header() {
  return Container(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        CircleAvatar(
          backgroundImage: NetworkImage(
              'https://media.sproutsocial.com/uploads/2022/06/profile-picture.jpeg'),
        ),
        SizedBox(
          height: 10,
        ),
        Text("juyjgjg"),
        Text("he is a ironman")
      ],
    ),
  );
}
