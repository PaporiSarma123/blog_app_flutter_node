import 'dart:ui';
import 'dart:convert';
import 'dart:async';

import 'package:demo/screen/homePage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:demo/api.dart';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SignIn extends StatefulWidget {
  const SignIn({super.key});

  @override
  State<SignIn> createState() => _SignInState();
}

class _SignInState extends State<SignIn> with TickerProviderStateMixin {
  final TextEditingController _passwordCnt = TextEditingController();
  final TextEditingController _usernameCnt = TextEditingController();
  late String errString = '';
  late bool circular = false;
  late bool validate = true;
  final storage = new FlutterSecureStorage();

  late AnimationController _controler1;
  late Animation<Offset> animation2;

  var vis = true;
  final _globalKey = GlobalKey<FormState>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controler1 = AnimationController(
        duration: Duration(milliseconds: 1400), vsync: this);

    animation2 = Tween<Offset>(begin: Offset(0.0, 1.0), end: Offset(0.0, 0.0))
        .animate(CurvedAnimation(parent: _controler1, curve: Curves.easeInOut));

    _controler1.forward();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _controler1.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Map<String, String> data;

    var validate2 = validate;
    return Scaffold(
      body: Center(
        child: Form(
          key: _globalKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Center(
                  child: Text(
                'Sign In',
                style: TextStyle(color: Colors.purple, fontSize: 36),
              )),
              SlideTransition(
                position: animation2,
                child: Container(
                    width: MediaQuery.of(context).size.width - 200,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextFormField(
                            validator: ((value) {
                              if (value!.isEmpty) return 'username is empty';
                            }),
                            controller: _usernameCnt,
                            onChanged: (v) => {_usernameCnt.text = v},
                            decoration: const InputDecoration(
                              errorText: 'Invalid username',
                              helperText: "type your email",
                              helperStyle:
                                  TextStyle(color: Colors.red, fontSize: 10),
                              border:
                                  OutlineInputBorder(), //nderlineInputBorder(),
                              labelText: "email",
                            ),
                          ),
                        )
                      ],
                    )),
              ),
              SlideTransition(
                position: animation2,
                child: Container(
                    width: MediaQuery.of(context).size.width - 200,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextFormField(
                            validator: ((value) {
                              if (value!.isEmpty) return 'email is empty';
                              if (value.length <= 8) {
                                return 'password must be greater then 8';
                              }
                            }),
                            obscureText: vis,
                            controller: _passwordCnt,
                            onChanged: (v) => {_passwordCnt.text = v},
                            decoration: InputDecoration(
                              helperText:
                                  "type your paasword more then 8 chracter",
                              helperStyle:
                                  TextStyle(color: Colors.red, fontSize: 10),
                              suffixIcon: IconButton(
                                icon: Icon(vis
                                    ? Icons.visibility_off
                                    : Icons.visibility),
                                onPressed: () => {
                                  setState(
                                    () {
                                      vis = !vis;
                                    },
                                  )
                                },
                              ),
                              border: OutlineInputBorder(),
                              labelText: "password",
                            ),
                          ),
                        )
                      ],
                    )),
              ),
              SizedBox(
                height: 20,
              ),
              SlideTransition(
                position: animation2,
                child: ElevatedButton(
                    onPressed: () async {
                      setState(() => {circular = true});
                      print(' mrinmoy .....');
                      // await checkUser();

                      Map<String, String> data = {
                        "username": _usernameCnt.text,
                        "password": _passwordCnt.text
                      };
                      print(data);

                      var response = await post("/login", data);
                      print(response);

                      Map<String, dynamic> output;

                      if (response.statusCode == 200 ||
                          response.statusCode == 201) {
                        output = json.decode(response.body);
                        print(output["token"]);

                        await storage.write(
                            key: 'token', value: output['token']);
                        setState(() {
                          validate = false;
                          circular = false;
                        });

                        Navigator.pushAndRemoveUntil(
                            context,
                            (MaterialPageRoute(
                                builder: (context) => HomePage())),
                            (route) => false);
                      } else {
                        String outputi = json.decode(response.body);
                        setState(() {
                          circular = false;
                          errString = outputi; //'yes new user michel';
                        });
                      }
                    },
                    child: Container(
                      padding: EdgeInsets.all(8),
                      child: circular
                          ? CircularProgressIndicator()
                          : const Text(
                              'sign In here',
                              style:
                                  TextStyle(color: Colors.white, fontSize: 20),
                            ),
                    )),
              )
            ],
          ),
        ),
      ),
    );
  }

  checkUser() async {
    if (_usernameCnt.text.length == 0) {
      setState(() {
        circular = false;
        validate = false;
        errString = 'username cannot be empty';
      });
    } else {
      var response = await get('/user/checkusername/${_usernameCnt.text}');
      if (response["status"]) {
        setState(() {
          validate = false;
          errString = "username already taken";
        });
      } else {
        setState(() {
          validate = true;
        });
      }
    }
  }
}
